@echo off
echo ====================================
echo  赞链 · 一键推送到 GitHub
echo ====================================
echo.

cd /d "C:\Users\ren02\zanlian"

echo [1/4] 设置 Git 配置...
git config user.email "03laozu@gmail.com"
git config user.name "zanlian-dev"

echo [2/4] 添加远程仓库...
git remote remove origin 2>nul
git remote add origin https://makeloftergreat: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@github.com/makeloftergreat/zanlian.git

echo [3/4] 推送代码到 GitHub...
git push -u origin main 2>&1
if %errorlevel% equ 0 (
    echo.
    echo [成功] 代码已推送到 GitHub！
) else (
    echo.
    echo [重试] 第一次失败，再试一次...
    git push -u origin main --force 2>&1
    if %errorlevel% equ 0 (
        echo.
        echo [成功] 代码已推送到 GitHub！
    ) else (
        echo.
        echo [提示] 推送失败，请检查网络。
        echo 也可以手动在 GitHub 上创建空仓库 zanlian，再运行此脚本。
    )
)

echo.
echo ====================================
pause
