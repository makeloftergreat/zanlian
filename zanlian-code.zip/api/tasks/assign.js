// POST /api/tasks/assign
// 领取一个新任务
import { assignTask } from '../_lib/supabase.js'

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')

  if (req.method === 'OPTIONS') {
    return res.status(200).end()
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const { userId } = req.body

    if (!userId) {
      return res.status(400).json({ error: '缺少 userId' })
    }

    const result = await assignTask(userId)

    if (!result) {
      return res.status(200).json({ task: null, message: '当前队列为空，没有可领取的任务' })
    }

    return res.status(200).json(result)
  } catch (error) {
    console.error('Assign task error:', error)
    return res.status(500).json({ error: '服务器内部错误' })
  }
}
