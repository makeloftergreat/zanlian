// GET /api/tasks/pending?userId=X
// 获取当前待处理任务
import { getPendingTasks, getUserById } from '../_lib/supabase.js'

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const userId = parseInt(req.query.userId)
    if (!userId) {
      return res.status(400).json({ error: '缺少 userId 参数' })
    }

    const tasks = await getPendingTasks(userId)

    // 附带目标用户信息
    const enriched = await Promise.all(tasks.map(async (task) => {
      const target = await getUserById(task.target_user)
      return { ...task, targetUser: target }
    }))

    return res.status(200).json({ tasks: enriched })
  } catch (error) {
    console.error('Get pending tasks error:', error)
    return res.status(500).json({ error: '服务器内部错误' })
  }
}
