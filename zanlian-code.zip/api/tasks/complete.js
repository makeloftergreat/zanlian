// POST /api/tasks/complete
// 完成任务
import { completeTask, getUserById, logLike, updateUserStats } from '../_lib/supabase.js'

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')

  if (req.method === 'OPTIONS') {
    return res.status(200).end()
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const { taskId, userId, ipHash } = req.body

    if (!taskId || !userId) {
      return res.status(400).json({ error: '缺少必填字段' })
    }

    // 完成任务
    const task = await completeTask(taskId)
    if (!task) {
      return res.status(404).json({ error: '任务不存在或已被处理' })
    }

    // 获取目标用户
    const targetUser = await getUserById(task.target_user)

    // 记录日志
    await logLike({
      likerId: userId,
      receiverId: targetUser.id,
      articleUrl: task.target_article_url,
      taskId: task.id,
      ipHash: ipHash || null,
    })

    // 更新统计 (异步, 不阻塞)
    updateUserStats(userId, { given: 1 }).catch(e => console.error('Update stats error:', e))
    updateUserStats(targetUser.id, { received: 1 }).catch(e => console.error('Update stats error:', e))

    return res.status(200).json({ task, targetUser })
  } catch (error) {
    console.error('Complete task error:', error)
    return res.status(500).json({ error: '服务器内部错误' })
  }
}
