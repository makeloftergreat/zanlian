// GET /api/logs
// 获取点赞溯源日志
import { getLikeLogs } from '../_lib/supabase.js'

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const limit = Math.min(parseInt(req.query.limit) || 50, 100)
    const logs = await getLikeLogs(limit)
    return res.status(200).json({ logs })
  } catch (error) {
    console.error('Get logs error:', error)
    return res.status(500).json({ error: '服务器内部错误' })
  }
}
