// GET /api/stats
// 获取平台统计数据
import { getStats } from '../_lib/supabase.js'

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const stats = await getStats()
    return res.status(200).json({ stats })
  } catch (error) {
    console.error('Get stats error:', error)
    return res.status(500).json({ error: '服务器内部错误' })
  }
}
