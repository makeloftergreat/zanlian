// 赞链 · Supabase 客户端
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.SUPABASE_URL
const supabaseKey = process.env.SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing SUPABASE_URL or SUPABASE_ANON_KEY environment variables')
}

export const supabase = createClient(supabaseUrl, supabaseKey)

// --- 用户操作 ---

/**
 * 注册/创建用户 (马甲号A + 创作号B)
 */
export async function createUser({ altUsername, creatorUsername, altUid, creatorUid }) {
  const { data, error } = await supabase
    .from('users')
    .insert({
      alt_username: altUsername,
      creator_username: creatorUsername,
      alt_uid: altUid || null,
      creator_uid: creatorUid || null,
    })
    .select()
    .single()

  if (error) throw error
  return data
}

/**
 * 通过马甲用户名查找用户
 */
export async function getUserByAltUsername(altUsername) {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('alt_username', altUsername)
    .single()

  if (error && error.code !== 'PGRST116') throw error
  return data
}

/**
 * 获取用户详情
 */
export async function getUserById(id) {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', id)
    .single()

  if (error) throw error
  return data
}

/**
 * 更新用户统计数据
 */
export async function updateUserStats(id, { given = 0, received = 0 }) {
  const updates = {}
  if (given) updates.total_given = supabase.rpc('increment', { x: given })
  if (received) updates.total_received = supabase.rpc('increment', { x: received })

  const { data, error } = await supabase
    .from('users')
    .update(updates)
    .eq('id', id)
    .select()
    .single()

  if (error) throw error
  return data
}

// --- 任务操作 ---

/**
 * 领取一个任务（系统分配）
 */
export async function assignTask(assignedToUserId) {
  // 1. 找排队队列中最前面的人(排除自己)
  const { data: queueItem, error: queueError } = await supabase
    .from('queue')
    .select('*')
    .neq('user_id', assignedToUserId)
    .eq('status', 'waiting')
    .order('priority', { ascending: false })
    .order('created_at', { ascending: true })
    .limit(1)
    .single()

  if (queueError) {
    if (queueError.code === 'PGRST116') return null // 队列为空
    throw queueError
  }

  // 2. 获取目标用户信息
  const targetUser = await getUserById(queueItem.user_id)

  // 3. 创建任务
  const { data: task, error: taskError } = await supabase
    .from('tasks')
    .insert({
      assigned_to: assignedToUserId,
      target_user: targetUser.id,
      target_article_url: queueItem.article_url,
      status: 'pending',
    })
    .select()
    .single()

  if (taskError) throw taskError

  // 4. 更新队列状态为 matched
  await supabase
    .from('queue')
    .update({ status: 'matched', matched_by: task.id })
    .eq('id', queueItem.id)

  return { task, targetUser }
}

/**
 * 完成任务
 */
export async function completeTask(taskId) {
  const { data, error } = await supabase
    .from('tasks')
    .update({ status: 'completed', completed_at: new Date().toISOString() })
    .eq('id', taskId)
    .eq('status', 'pending')
    .select()
    .single()

  if (error) throw error
  return data
}

/**
 * 获取用户当前待处理任务
 */
export async function getPendingTasks(userId) {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .eq('assigned_to', userId)
    .eq('status', 'pending')
    .order('created_at', { ascending: false })

  if (error) throw error
  return data
}

// --- 排队操作 ---

/**
 * 加入排队队列
 */
export async function joinQueue(userId, articleUrl) {
  const { data, error } = await supabase
    .from('queue')
    .insert({
      user_id: userId,
      article_url: articleUrl,
      priority: 'normal',
      status: 'waiting',
    })
    .select()
    .single()

  if (error) throw error
  return data
}

/**
 * 获取排队队列
 */
export async function getQueue() {
  const { data, error } = await supabase
    .from('queue')
    .select('*, users!inner(alt_username, creator_username)')
    .eq('status', 'waiting')
    .order('priority', { ascending: false })
    .order('created_at', { ascending: true })

  if (error) throw error
  return data
}

/**
 * 获取用户的排队位置
 */
export async function getUserQueuePosition(userId) {
  const { data, error } = await supabase
    .rpc('get_queue_position', { p_user_id: userId })

  if (error) throw error
  return data
}

// --- 日志操作 ---

/**
 * 记录点赞
 */
export async function logLike({ likerId, receiverId, articleUrl, taskId, ipHash }) {
  const { data, error } = await supabase
    .from('like_logs')
    .insert({
      liker_id: likerId,
      receiver_id: receiverId,
      article_url: articleUrl,
      task_id: taskId,
      ip_hash: ipHash,
    })
    .select()
    .single()

  if (error) throw error
  return data
}

/**
 * 获取点赞溯源日志
 */
export async function getLikeLogs(limit = 50) {
  const { data, error } = await supabase
    .from('like_logs')
    .select('*, liker:users!liker_id(alt_username), receiver:users!receiver_id(creator_username)')
    .order('created_at', { ascending: false })
    .limit(limit)

  if (error) throw error
  return data
}

// --- 统计数据 ---

/**
 * 获取平台统计数据
 */
export async function getStats() {
  const [usersRes, tasksRes, queueRes, logsRes] = await Promise.all([
    supabase.from('users').select('id', { count: 'exact', head: true }),
    supabase.from('tasks').select('id', { count: 'exact', head: true }).eq('status', 'completed'),
    supabase.from('queue').select('id', { count: 'exact', head: true }).eq('status', 'waiting'),
    supabase.from('like_logs').select('id', { count: 'exact', head: true }),
  ])

  return {
    total_users: usersRes.count || 0,
    total_completed: tasksRes.count || 0,
    queue_size: queueRes.count || 0,
    total_likes: logsRes.count || 0,
  }
}
