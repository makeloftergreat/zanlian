// POST /api/queue/join
// 加入排队队列
import { joinQueue } from '../_lib/supabase.js'

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')

  if (req.method === 'OPTIONS') {
    return res.status(200).end()
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const { userId, articleUrl } = req.body

    if (!userId || !articleUrl) {
      return res.status(400).json({ error: '缺少必填字段：userId, articleUrl' })
    }

    const queueItem = await joinQueue(userId, articleUrl)

    return res.status(201).json({ queueItem })
  } catch (error) {
    console.error('Join queue error:', error)
    return res.status(500).json({ error: '服务器内部错误' })
  }
}
