// GET /api/queue/list
// 获取排队队列
import { getQueue } from '../_lib/supabase.js'

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const queue = await getQueue()
    return res.status(200).json({ queue })
  } catch (error) {
    console.error('Get queue error:', error)
    return res.status(500).json({ error: '服务器内部错误' })
  }
}
