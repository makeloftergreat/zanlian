// GET /api/auth/login
// 登录 (验证用户身份后返回用户信息)
import { getUserByAltUsername } from '../_lib/supabase.js'

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')

  if (req.method === 'OPTIONS') {
    return res.status(200).end()
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const { altUsername } = req.body

    if (!altUsername) {
      return res.status(400).json({ error: '缺少马甲用户名' })
    }

    const user = await getUserByAltUsername(altUsername)

    if (!user) {
      return res.status(404).json({ error: '用户不存在，请先注册' })
    }

    return res.status(200).json({ user })
  } catch (error) {
    console.error('Login error:', error)
    return res.status(500).json({ error: '服务器内部错误' })
  }
}
