// POST /api/auth/register
// 注册用户 (绑定马甲号A + 创作号B)
import { createUser, getUserByAltUsername } from '../_lib/supabase.js'

export default async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')

  if (req.method === 'OPTIONS') {
    return res.status(200).end()
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const { altUsername, creatorUsername, altUid, creatorUid } = req.body

    if (!altUsername || !creatorUsername) {
      return res.status(400).json({ error: '缺少必填字段：altUsername 和 creatorUsername' })
    }

    // 检查是否已注册
    const existing = await getUserByAltUsername(altUsername)
    if (existing) {
      return res.status(409).json({ error: '该马甲号已注册', user: existing })
    }

    const user = await createUser({ altUsername, creatorUsername, altUid, creatorUid })

    return res.status(201).json({ user })
  } catch (error) {
    console.error('Register error:', error)
    return res.status(500).json({ error: '服务器内部错误' })
  }
}
