# ♥ 赞链 · LOFTER 点赞互助平台

用马甲点赞，主号收赞。双账号隔离，创作号零风险。

## 技术栈

- **前端**: 纯 HTML/CSS/JS（无框架，轻量快速）
- **托管**: Vercel
- **数据库**: Supabase (PostgreSQL)
- **API**: Vercel Serverless Functions

## 本地开发

```bash
# 安装依赖
npm install

# 启动本地开发服务器
npm run dev
```

## 环境变量

在 `.env` 文件中设置：

```
SUPABASE_URL=你的Supabase项目URL
SUPABASE_ANON_KEY=你的Supabase匿名密钥
```

## 部署

```bash
# 部署到Vercel
npm run deploy
```
