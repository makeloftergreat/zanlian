-- ============================================================
-- 赞链 · LOFTER 点赞互助平台 · Supabase Schema
-- ============================================================

-- 1. 用户表 (双账号绑定)
CREATE TABLE public.users (
  id            BIGSERIAL PRIMARY KEY,
  -- 账号A (马甲号)
  alt_username  TEXT NOT NULL UNIQUE,           -- LOFTER马甲用户名
  alt_uid       TEXT,                           -- LOFTER UID (可选)
  -- 账号B (创作主号)
  creator_username TEXT NOT NULL,               -- 创作号用户名
  creator_uid   TEXT,                           -- 创作号UID (可选)
  -- 状态
  is_vip        BOOLEAN NOT NULL DEFAULT false,
  vip_expires_at TIMESTAMPTZ,
  total_given   INTEGER NOT NULL DEFAULT 0,     -- 累计付出赞数
  total_received INTEGER NOT NULL DEFAULT 0,    -- 累计收获赞数
  is_active     BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 用户唯一约束：一个马甲只能绑定一个创作号
CREATE UNIQUE INDEX idx_users_alt ON public.users (alt_username);

-- 2. 任务表
CREATE TABLE public.tasks (
  id            BIGSERIAL PRIMARY KEY,
  -- 谁被分配了这个任务
  assigned_to   BIGINT NOT NULL REFERENCES public.users(id),
  -- 要帮谁点赞
  target_user   BIGINT NOT NULL REFERENCES public.users(id),
  target_article_url TEXT NOT NULL,            -- 目标文章链接
  -- 状态: pending, in_progress, completed, failed
  status        TEXT NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending', 'in_progress', 'completed', 'failed')),
  completed_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_tasks_assigned ON public.tasks (assigned_to, status);
CREATE INDEX idx_tasks_target ON public.tasks (target_user, status);

-- 3. 排队队列
CREATE TABLE public.queue (
  id            BIGSERIAL PRIMARY KEY,
  user_id       BIGINT NOT NULL REFERENCES public.users(id),
  article_url   TEXT NOT NULL,                  -- 创作号最新文章
  -- 优先级: vip > normal, 相同优先级按 created_at 排序
  priority      TEXT NOT NULL DEFAULT 'normal'
                CHECK (priority IN ('vip', 'normal')),
  status        TEXT NOT NULL DEFAULT 'waiting'
                CHECK (status IN ('waiting', 'matched', 'completed')),
  matched_by    BIGINT REFERENCES public.tasks(id),  -- 哪个任务匹配了
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  matched_at    TIMESTAMPTZ
);

CREATE INDEX idx_queue_status ON public.queue (status, priority, created_at);

-- 4. 点赞溯源日志
CREATE TABLE public.like_logs (
  id            BIGSERIAL PRIMARY KEY,
  -- 谁点的赞 (马甲号)
  liker_id      BIGINT NOT NULL REFERENCES public.users(id),
  -- 谁收到的赞 (创作号)
  receiver_id   BIGINT NOT NULL REFERENCES public.users(id),
  article_url   TEXT NOT NULL,                  -- 被点赞文章
  task_id       BIGINT REFERENCES public.tasks(id),
  ip_hash       TEXT,                           -- IP哈希 (隐私保护)
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_logs_liker ON public.like_logs (liker_id);
CREATE INDEX idx_logs_receiver ON public.like_logs (receiver_id);
CREATE INDEX idx_logs_time ON public.like_logs (created_at DESC);

-- 5. VIP订阅
CREATE TABLE public.vip_subscriptions (
  id            BIGSERIAL PRIMARY KEY,
  user_id       BIGINT NOT NULL REFERENCES public.users(id),
  -- 每日插队权配额
  daily_skip_quota   INTEGER NOT NULL DEFAULT 3,
  skip_used_today    INTEGER NOT NULL DEFAULT 0,
  -- 订阅周期
  start_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  end_at        TIMESTAMPTZ NOT NULL,
  is_active     BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_vip_user ON public.vip_subscriptions (user_id, is_active);

-- ============================================================
-- 行级安全策略 (RLS)
-- ============================================================
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.like_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vip_subscriptions ENABLE ROW LEVEL SECURITY;

-- 允许匿名用户读取必要的公开数据
CREATE POLICY "Public users read" ON public.users
  FOR SELECT USING (true);

CREATE POLICY "Public queue read" ON public.queue
  FOR SELECT USING (true);

CREATE POLICY "Public logs read" ON public.like_logs
  FOR SELECT USING (true);

-- 用户只能写入自己的数据 (通过anon key + user_id验证)
CREATE POLICY "Users insert own" ON public.users
  FOR INSERT WITH CHECK (true);  -- 注册阶段

CREATE POLICY "Users update own" ON public.users
  FOR UPDATE USING (true);  -- 业务逻辑层验证

-- ============================================================
-- 自动更新 updated_at 触发器
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at
  BEFORE UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
